// GLOBALS

Player player;
ArrayList<Wall> walls;

Key keyItem;
Door door;
Box box;
PressurePlate plate;

boolean hasKey = false;
int level = 1;

String gameState = "menu";

boolean wPressed, aPressed, sPressed, dPressed;

// SETUP

void setup() {
  size(800, 400);
  gameState = "menu";
}

// INIT GAME

void initGame() {

  walls = new ArrayList<Wall>();

  if (level == 1) buildLevel1();
  else if (level == 2) buildLevel2();
  else if (level == 3) buildLevel3();
  else {
    gameState = "win";
    return;
  }

  hasKey = false;
  gameState = "game";
}

// DRAW LOOP

void draw() {
  background(30);

  if (gameState.equals("menu")) drawMenu();
  else if (gameState.equals("game")) runGame();
  else if (gameState.equals("gameover")) drawGameOver();
  else if (gameState.equals("win")) drawWin();
}

// GAME LOOP

void runGame() {

  for (Wall w : walls) w.display();

  plate.update(box);
  plate.display();

  keyItem.display();
  door.display();
  box.display();

  keyItem.checkPickup(player);
  door.check(player);

  player.update();
  player.display();

  fill(255);
}

// SCREENS

void drawMenu() {
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("PW_Game", width/2, 120);
  textSize(20);
  text("Click to Start", width/2, 200);
}

void drawGameOver() {
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("Game Over", width/2, 150);
  textSize(20);
  text("Click to Restart", width/2, 220);
}

void drawWin() {
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("YOU WIN!", width/2, 150);
  textSize(20);
  text("Click to Replay", width/2, 220);
}

// INPUT

void mousePressed() {
  if (gameState.equals("menu") || gameState.equals("gameover") || gameState.equals("win")) {
    level = 1;
    initGame();
  }
}

void keyPressed() {
  if (key == 'w') wPressed = true;
  if (key == 'a') aPressed = true;
  if (key == 's') sPressed = true;
  if (key == 'd') dPressed = true;
}

void keyReleased() {
  if (key == 'w') wPressed = false;
  if (key == 'a') aPressed = false;
  if (key == 's') sPressed = false;
  if (key == 'd') dPressed = false;
}

// LEVELS

void buildBorders() {
  walls.add(new Wall(0, 0, 800, 20));
  walls.add(new Wall(0, 380, 800, 20));
  walls.add(new Wall(0, 0, 20, 400));
  walls.add(new Wall(780, 0, 20, 400));
}

void buildLevel1() {
  buildBorders();

  player = new Player(50, 50);
  keyItem = new Key(400, 200);
  door = new Door(740, 320);
  box = new Box(200, 200);
  plate = new PressurePlate(500, 200);

  walls.add(new Wall(200, 100, 400, 20));
}

void buildLevel2() {
  buildBorders();

  player = new Player(50, 50);
  keyItem = new Key(700, 80);
  door = new Door(740, 320);
  box = new Box(250, 250);
  plate = new PressurePlate(150, 250);

  walls.add(new Wall(150, 80, 20, 240));
  walls.add(new Wall(300, 0, 20, 250));
  walls.add(new Wall(450, 100, 20, 250));
}

void buildLevel3() {
  buildBorders();

  player = new Player(60, 300);
  keyItem = new Key(700, 50);
  door = new Door(740, 320);
  box = new Box(300, 200);
  plate = new PressurePlate(500, 150);

  walls.add(new Wall(200, 0, 20, 300));
  walls.add(new Wall(400, 100, 20, 300));
  walls.add(new Wall(600, 0, 20, 250));
}

// PLAYER

class Player {
  float x, y;
  float r = 10;
  float speed = 2;

  Player(float x, float y) {
    this.x = x;
    this.y = y;
  }

  void update() {

    float dx = 0, dy = 0;

    if (wPressed) dy--;
    if (sPressed) dy++;
    if (aPressed) dx--;
    if (dPressed) dx++;

    float mag = sqrt(dx*dx + dy*dy);
    if (mag != 0) {
      dx /= mag;
      dy /= mag;
    }

    move(dx * speed, dy * speed);
  }

  void move(float dx, float dy) {

    float nx = x + dx;
    float ny = y + dy;

    // Try pushing box first
    if (boxCollides(nx, y, r)) {
      if (box.tryMove(dx, 0)) x = nx;
    } else if (!collidesAny(nx, y, r)) {
      x = nx;
    }

    if (boxCollides(x, ny, r)) {
      if (box.tryMove(0, dy)) y = ny;
    } else if (!collidesAny(x, ny, r)) {
      y = ny;
    }
  }

  void display() {
    fill(0, 200, 255);
    ellipse(x, y, r*2, r*2);
  }
}

// BOX

class Box {
  float x, y;
  float size = 20;

  Box(float x, float y) {
    this.x = x;
    this.y = y;
  }

  boolean tryMove(float dx, float dy) {
    float nx = x + dx;
    float ny = y + dy;

    if (!collidesAny(nx, ny, size/2)) {
      x = nx;
      y = ny;
      return true;
    }
    return false;
  }

  void display() {
    rectMode(CENTER);
    fill(160, 100, 60);
    rect(x, y, size, size);
    rectMode(CORNER);
  }
}

// KEY

class Key {
  float x, y;
  boolean taken = false;

  Key(float x, float y) {
    this.x = x;
    this.y = y;
  }

  void display() {
    if (!taken) {
      fill(255, 215, 0);
      ellipse(x, y, 12, 12);
    }
  }

  void checkPickup(Player p) {
    if (!taken && dist(p.x, p.y, x, y) < 15) {
      taken = true;
      hasKey = true;
    }
  }
}

// DOOR

class Door {
  float x, y, w = 30, h = 40;

  Door(float x, float y) {
    this.x = x;
    this.y = y;
  }

  void display() {
    fill(hasKey && plate.active ? color(0, 200, 0) : color(150));
    rect(x, y, w, h);
  }

  void check(Player p) {
    if (hasKey && plate.active &&
        p.x + p.r > x && p.x - p.r < x + w &&
        p.y + p.r > y && p.y - p.r < y + h) {

      level++;
      initGame();
    }
  }
}

// PRESSURE PLATE

class PressurePlate {
  float x, y;
  float size = 20;
  boolean active = false;

  PressurePlate(float x, float y) {
    this.x = x;
    this.y = y;
  }

  void update(Box b) {
    float half = size / 2;
    float bHalf = b.size / 2;

    active = (abs(b.x - x) < half + bHalf &&
              abs(b.y - y) < half + bHalf);
  }

  void display() {
    rectMode(CENTER);
    fill(active ? color(0, 255, 0) : color(200, 100, 0));
    rect(x, y, size, size);
    rectMode(CORNER);
  }
}

// WALLS

class Wall {
  float x, y, w, h;

  Wall(float x, float y, float w, float h) {
    this.x = x; this.y = y; this.w = w; this.h = h;
  }

  void display() {
    fill(150);
    rect(x, y, w, h);
  }

  boolean collides(float px, float py, float r) {
    return (px + r > x && px - r < x + w &&
            py + r > y && py - r < y + h);
  }
}

// COLLISION

boolean collidesAny(float px, float py, float r) {
  for (Wall w : walls)
    if (w.collides(px, py, r)) return true;
  return false;
}

boolean boxCollides(float px, float py, float r) {
  float half = box.size / 2;

  return (px + r > box.x - half &&
          px - r < box.x + half &&
          py + r > box.y - half &&
          py - r < box.y + half);
}
