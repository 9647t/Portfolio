class Game {
  ArrayList<Enemy> enemies;
  int score = 0;

  int lastSpawnTime = 0;
  int spawnInterval = 2000;

  boolean gameOver = false;

  Game() {
    enemies = new ArrayList<Enemy>();
    enemies.add(spawnEnemy());
  }

  void update() {
    if (gameOver) return;

    // spawn enemies over time
    if (millis() - lastSpawnTime > spawnInterval) {
      enemies.add(spawnEnemy());
      lastSpawnTime = millis();

      if (spawnInterval > 500) {
        spawnInterval -= 100;
      }
    }


    // update enemies
    for (Enemy e : enemies) {
      e.update();

      // check if enemy reached center
      if (dist(e.x, e.y, width/2, height/2) < e.size/2) {
        gameOver = true;
      }
    }
  }

  void display() {
    if (gameOver) {
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(40);
      text("GAME OVER", width/2, height/2);
      return;
    }

    // draw enemies
    for (Enemy e : enemies) {
      e.display();
    }

    // draw score
    fill(255);
    textSize(20);
    textAlign(LEFT, TOP);
    text("Score: " + score, 10, 10);
  }

  void mousePressed() {
    if (gameOver) return;

    for (int i = enemies.size() - 1; i >= 0; i--) {
      Enemy e = enemies.get(i);

      if (e.isClicked(mouseX, mouseY)) {
        enemies.remove(i);
        score++;
      }
    }
  }

  Enemy spawnEnemy() {
    float ex, ey;
    int edge = int(random(3));

    if (edge == 0) { // top
      ex = random(width);
      ey = 0;
    } else if (edge == 1) { // left
      ex = 0;
      ey = random(height);
    } else { // right
      ex = width;
      ey = random(height);
    }

    return new Enemy(ex, ey);
  }
}
