class Enemy {
  float x, y;
  float speed;
  float size;
  color c;

  Enemy(float startX, float startY) {
    x = startX;
    y = startY;

    // choose enemy type
    int type = int(random(EnemyVariety));

    if (type == 0) {        // large
      speed = 1;
      size = 50;
      c = color(100, 0, 0);
    } else if (type == 1) { // medium
      speed = 2;
      size = 30;
      c = color(0, 50, 0);
    } else if (type == 2) {                // small
      speed = 3;
      size = 25;
      c = color(0, 0, 100);
    } else if (type == 3) {
      speed = 3.3;
      size = 25;
      c = color(50,0,100);
    } else {
      speed = random(2,3.6);
      size = random(30,10);
      c = color(random(50),random(50),100);
 
 
     }
  }

  void update() {
    float dx = width/2 - x;
    float dy = height/2 - y;
    float angle = atan2(dy, dx);

    x += cos(angle) * speed;
    y += sin(angle) * speed;
  }

  void display() {
    fill(c);
    ellipse(x, y, size, size);
  }

  boolean isClicked(float mx, float my) {
    return dist(mx, my, x, y) < size/2;
  }
}
