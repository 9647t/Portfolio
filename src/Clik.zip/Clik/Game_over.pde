class Gameover {
  
  Gameover() {
    display();
  }
  
  void display() {
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(32);
    text("Game Over.", width/2, 100);
  }
}
