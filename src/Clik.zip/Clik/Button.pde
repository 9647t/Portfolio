class Button {
  float x, y, w, h;
  String label;
  
  Button(float x_, float y_, float w_, float h_, String label_) {
    x = x_;
    y = y_;
    w = w_;
    h = h_;
    label = label_;
  }
  
  void display() {
    fill(55);
    rect(x, y, w, h, 10);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(24);
    text(label, x + w/2, y + h/2);
  }
  
  boolean isClicked(float mx, float my) {
    return mx > x && mx < x + w && my > y && my < y + h;
  }
}
